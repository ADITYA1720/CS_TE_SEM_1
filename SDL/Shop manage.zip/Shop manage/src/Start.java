import java.lang.*;
import activity.*;

public class Start {
	public static void main(String args[]) {
		Landing la = new Landing();
		la.setVisible(true);
	}
	
}